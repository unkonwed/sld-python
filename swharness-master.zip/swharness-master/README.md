swharness
=========

Test harness for my SolidWorks Simulation project